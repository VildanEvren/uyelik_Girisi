<?php 
 
include("ayar.php");
ob_start();
session_start();
 
if(!isset($_SESSION["login"])){
    header("Location:uyelikGirisi.php");
}
else {
    echo "<center>Admin sayfasina hosgeldiniz..! ";
    echo "<a href=logout.php>Guvenli cikis</a></center>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>
<body>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">Products</a></li>
        <li><a href="#">Deals</a></li>
        <li><a href="#">Stores</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Your Account</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
    </div>
  </div>
</nav>



<div class="container">
  <div class="row">
    <div class="col-lg-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Personel Konumu</div>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<title>Tarayıcıdan Konum Bilgisi Alma</title>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript">

//Konumu bulup fonksiyonlara yönlendirme yap
if(navigator.geolocation){
  navigator.geolocation.getCurrentPosition(success, error);
}else{
  error('Desteklenmiyor.');
}
 
//Konum bulunduysa
function success(position){
  var status = document.querySelector('#durum');
 
  if (status.className == 'basarili'){
    return;
  }
 
  status.innerHTML = "bulundu.";
  status.className = 'basarili';
 
  var mapcanvas = document.createElement('div');
  mapcanvas.id = 'mapcanvas';
  mapcanvas.style.width = 'auto';
  mapcanvas.style.height = '400px';
 
  document.querySelector('div').appendChild(mapcanvas);
 
  var kordinat = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
  var myOptions = {
    zoom: 15,
    center: kordinat,
    mapTypeControl: false,
    navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  var map = new google.maps.Map(document.getElementById("mapcanvas"), myOptions);
 
  document.getElementById("konum").innerHTML='Kordinatlarınız: '+kordinat;
  
  //var str=kordinat.toString();
  //document.getElementById("konum").innerHTML=str;
  //window.location = "page-down.php?veri=" + str.substring(1,38);
  
  var marker = new google.maps.Marker({
      position: kordinat,
      map: map,
      title:"Buradasın"
  });
}
 
 
 

 
 
 
//Hata ile karşılaşıldıysa
function error(msg){
  var status = document.querySelector('#durum');
  status.innerHTML = typeof msg == 'string' ? msg : "bulunamadı";
  status.className = 'basarisiz';
 
}
</script>
</head>
<body>
<div>
<p>Konumunuz: <span id="durum">hesaplanıyor...</span></p>
<p><span id="konum"></span></p>
</div>
</body>
</html>
        <div class="panel-footer"></div>
      </div>
    </div>
   
   
   
   
   

<div class="container">
  <div class="row">
    <div class="col-lg-4">
      <div class="panel panel-danger">
        <div class="panel-heading">Personel</div>
        
<?php 
        // Server Kullanıcı Adımız
        $user        =    "root";
        // Server Kullanıcı Şifremiz
        $pass        =    "";
        // Server Adresimiz
        $host        =    "localhost";
        // Veritabanı Adımız
        $db            =    "tasarimciweb";
        
        //Veritabanı Bağlantısı Oluşturalım.
        $baglan = mysql_connect($host,$user,$pass) or die(mysql_error());
        
        //Veritabanına Bağlanalım.
        mysql_select_db($db,$baglan) or die(mysql_error());    
?>

              <div class="tab-content">
			  
			  
			  
			  
           <div class="AnasayfaTab tab-pane fade in active" id="home">
       <div>
                   <h3><a href="" title="" class="text-success"></a> <span class="pull-right MakaleEkleyenBilgi"></h3>
 



<?php 
        // Server Kullanıcı Adımız
        $user        =    "root";
        // Server Kullanıcı Şifremiz
        $pass        =    "";
        // Server Adresimiz
        $host        =    "localhost";
        // Veritabanı Adımız
        $db            =    "tasarimciweb";
        
        //Veritabanı Bağlantısı Oluşturalım.
        $baglan = mysql_connect($host,$user,$pass) or die(mysql_error());
        
        //Veritabanına Bağlanalım.
        mysql_select_db($db,$baglan) or die(mysql_error());   



        // Form Gönderilmişmi Kontrolü Yapalım
        
		
		if($_POST)
		{
        if(isset($_POST['gonder']))
		{
		
            // Formdan Gelen Kayıtlar
            $adSoyad        =    $_POST["adSoyad"];
            $mesaj    =    $_POST["mesaj"];
            $gonderilmetarihi=date('d.m.Y H:i:s');
			/*if (isset($_GET['veri']))
			{
				$tmp=$_GET['veri'];
				$konumlar=explode(",",$tmp);
				$adSoyad=$konumlar[0];
				$mesaj=$konumlar[1];
			//echo $_GET['veri'];
			$ekle        =    mysql_query("insert into personel (adSoyad,mesaj) values ('$adSoyad','$mesaj')");
			}*/ 
            // Veritabanına Ekleyelim.
            $ekle        =    mysql_query("insert into personel (adSoyad,mesaj,tarih) values ('$adSoyad','$mesaj','$gonderilmetarihi')");
           
        }
		}
    ?>


<form action="" method="post">
        <table cellspacing="5" cellpadding="5" >
            <tr>
                <td>Ad ve Soyad:</td>
                <td><input  size="37" type="text" name="adSoyad" /></td>
            </tr>
			<tr>
                <td><br></td>
                
                
            </tr>
            <tr>
                <td>Mesaj:</td>
                <td><textarea name="mesaj" cols="40" rows="5"></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="gonder" value="Gönder" /></td>
            </tr>
        </table>
    </form>


           </div>
         </div>
       </div>
    
    </div>
    
</div><br><br>

<footer class="container-fluid text-center">
  
</footer>

</body>
</html>

